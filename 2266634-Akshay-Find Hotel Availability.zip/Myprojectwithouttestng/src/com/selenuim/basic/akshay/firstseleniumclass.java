package com.selenuim.basic.akshay;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

public class firstseleniumclass{

    
    public static void main(String[] args) throws InterruptedException {
    	WebDriver driver=null;
    		//open the URL with Selenium
    	String browser="chrome";
    		if(browser.equalsIgnoreCase("chrome")) {
    	    System.setProperty("webdriver.chrome.driver","C:\\Users\\2266634\\eclipse-workspace\\Myprojectwithouttestng\\driver\\chromedriver.exe");
    	    driver=new ChromeDriver();
    	    driver.manage().window().maximize();
    	}else{
    	    System.setProperty("webdriver.Edge.driver","C:\\Users\\2266634\\eclipse-workspace\\Myprojectwithouttestng\\driver\\msedgedriver.exe");
    	    driver=new EdgeDriver();
    	    
    		//to maximize the browser 
    	    driver.manage().window().maximize();
    	}
    		
        
    	String url="https://www.trivago.in";   
    	driver.get(url);

        //TO ENTER CITY
       WebElement city=driver.findElement(By.id("input-auto-complete"));
       city.click();
       city.sendKeys("Mumbai");
       Thread.sleep(1000);
       city.sendKeys(Keys.ENTER);
       
       //TO SELECT DATE
       WebElement date=driver.findElement(By.xpath("//*[@id=\"__next\"]/div[1]/div[1]/section/div[2]/div[3]/div/div[2]/div/div/div/div[3]/ul/li[4]/label"));
       date.click();
       
       //USED TO CLICK ON THE ROOM SELECTION OPTION
       WebElement s=driver.findElement(By.xpath("//*[@id=\"__next\"]/div[1]/div[1]/section/div[2]/div[3]/div/div[1]/button/span/span[2]/span[2]"));
       s.click();
       
       //SELECT ADULT AS ='1'
       WebElement p=driver.findElement(By.cssSelector("#__next > div.min-h-screen > div.mb-6.bg-gradient-to-br.from-white.to-grey-200 > section > div.mx-auto.Wrapper_box__4K_5d.px-4.\\32 xs\\:px-5.l\\:px-10.\\32 xl\\:px-5 > div.fresnel-container.fresnel-greaterThanOrEqual-2xl > div > div.z-60.absolute.top-0.subpixel-antialiased.pt-2.transition-transform.duration-200 > div > div > div.px-8.pt-6 > div > div.grid.grid-rows-3.gap-4.mb-6 > div:nth-child(1) > div > button:nth-child(1)"));
       p.click(); 
       Thread.sleep(2000);
      
       // CLICK ON APPLY BUTTON 
       WebElement apply=driver.findElement(By.className("PrimaryButton_small__8N1se"));
       apply.click();   
       Thread.sleep(1000);
       
        //To click on search buttons
    	List<WebElement> buttons = driver.findElements(By.tagName("button"));
     	System.out.println(buttons.size());
    	buttons.get(7).click();
    	Thread.sleep(50000);
    	
    	//used to click on the drop down button to select hotels according the rating
    	WebElement testDropDown= driver.findElement(By.id("sorting-selector"));
       Select  dropdown=new Select(testDropDown);
       dropdown.selectByVisibleText("Rating only");
       
       //used to cross the date pop-up
       WebElement m = driver.findElement(By.xpath("//span[@class='w-full text-center font-bold']"));
       m.click();
       Thread.sleep(2000);
      
        //to make the list of price of hotels
      	List<WebElement> listElement = driver.findElements(By.className("ClickoutArea_priceWrapper__Rcth1"));

        	   
         System.out.println("List size : " + listElement.size());
        	   
         for(WebElement price : listElement)
         {
        	 System.out.println(price.getText());
        	   }
        	   

       //Take screenshot

       File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

        try 
        {
        	Files.copy(screenshotFile.toPath(), new File("screenshot1.png").toPath(), StandardCopyOption.REPLACE_EXISTING);

        	System.out.println("Screenshot captured successfully.");

        } 
        	catch (IOException e) 
        {
        	System.out.println("Failed to capture the screenshot.");
        	e.printStackTrace();
        }
        	driver.close();
       
        }
        
    	
    	
    }


